# harness-cli
This repository contains the source code for harness cli commands.

## Usage
Harness CLI documentation : https://harness.atlassian.net/wiki/spaces/PD/pages/343900277/CLI+Installation+Walkthrough

## Development
`harness cli` is built in golang using `cobra` library for implementing commands and `go-modules` for dependency management.

Building source code
```
go build
```

Installing binary
```
go install
```

## Getting Started

1. Install `go-plugin` in VS Code.
2. Import the folder in VS Code, it will ask to install few more plugins, install those plugins too.

###   Debugging 

You will have to edit the `launch.json` file based on the command you want to debug. 
for eg : for login command 
```
"args": ["login", "-u", "admin@harness.io", "-p", "admin", "-m","localhost:3457"],
```
